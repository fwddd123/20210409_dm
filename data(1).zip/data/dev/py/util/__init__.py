#!/usr/bin/python3
# coding=utf-8
'''
项目名称:  
文件名称:   
描述: [类型描述] 
创建时间:  
方法：
公司信息: ************公司 *********部
@author 作者/**
@version v1.0 * 
@Title：
@update [序号][日期YYYY-MM-DD] [更改人姓名][变更描述]  
@Description: [功能描述]
@Param: 
@Return: 
@author 作者
@CreateDate:   
@update: [序号][日期YYYY-MM-DD] [更改人姓名][变更描述]
'''